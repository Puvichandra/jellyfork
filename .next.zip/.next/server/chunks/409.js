"use strict";
exports.id = 409;
exports.ids = [409];
exports.modules = {

/***/ 1409:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5368);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5623);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_google_recaptcha__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// import { ImageUpload } from '../ui/upload-preview'





function ListCoinForm() {
    const { 0: datafiledata , 1: setDatafiledata  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    // const [imagedata,setimagedata] = useState({file:'', imageblob:''});
    const { 0: imagedata , 1: setimagedata  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({
        file: "",
        imageblob: ""
    });
    const { 0: imagecloud , 1: setimagecloud  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: imageurl , 1: setimageurl  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: imagePreview , 1: setimagePreview  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const imgref = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const { 0: iscaptcha , 1: setIsCaptcha  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const { 0: captcha , 1: setCaptcha  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const skey = "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI";
    const { register , formState: { errors  } , handleSubmit ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_1__.useForm)({
        mode: "onTouched",
        defaultValues: {
            websitelink: "https://"
        }
    });
    const uploadImage = ()=>{
        const formData = new FormData();
        formData.append("file", imagecloud);
        formData.append("upload_preset", "akcblzz9");
        axios__WEBPACK_IMPORTED_MODULE_7___default().post("http://api.cloudinary.com/v1_1/dp9yoy7js/image/upload", formData).then((response)=>{
            if (response.statusText = "OK") {
                setimageurl(response.data.secure_url);
            }
        });
    };
    const onSubmit = (dd)=>{
        let validateval = false;
        const listingstatus = document.getElementById("lstat").value;
        const contractaddress = document.getElementById("cont").value;
        if (listingstatus === "presale" && contractaddress) {
            validateval = false;
        } else if (listingstatus === "presale" && !contractaddress) {
            validateval = true;
        } else if (listingstatus === "listed" && !contractaddress) {
            validateval = false;
        } else if (listingstatus === "listed" && contractaddress) {
            validateval = true;
        }
        if (validateval === true) {
            dd.captcha = captcha;
            //console.log(dd);
            setIsLoading(true);
            const formData = new FormData();
            formData.append("file", imagecloud);
            formData.append("upload_preset", "akcblzz9");
            //Axios.post("http://api.cloudinary.com/v1_1/dp9yoy7js/image/upload", formData)
            axios__WEBPACK_IMPORTED_MODULE_7___default().post("http://api.cloudinary.com/v1_1/dp9yoy7js/image/upload", formData).then((response)=>{
                dd.coinimage = response.data.secure_url;
                console.log(dd);
                updateDbase(dd);
            }).catch((e)=>{
                setIsLoading(false);
                alert("error  loading  picture in cloudinary");
            });
        } else {
            alert("When listing status is 'presale'  contract address field should be empty or if selected 'listed' info of contract address  is mandatory");
        }
    };
    const updateDbase = (dd)=>{
        fetch("/api/cndata", {
            method: "POST",
            body: JSON.stringify(dd),
            headers: {
                "Content-Type": "application/json"
            }
        }).then((res)=>res.json()
        ).then((data)=>{
            setIsLoading(false);
            window.location.reload(false);
        }).catch((e)=>{
            console.log("error in updating");
            setIsLoading(false);
            window.location.reload(false);
        });
    };
    const getDatajson = ()=>{
        fetch("/api/datajson").then((res)=>res.json()
        ).then((data)=>{
            setDatafiledata(data.datafile);
        });
    };
    // if (!image) {
    //   console.log('image is required');
    //   return false;
    //   }
    //   if (!image.name.match(/\.(jpg|jpeg|png|gif)$/)) {
    //     console.log('select valid image.');
    //    return false;
    //   }
    // const onImgLoad = ({ target: img }) => {
    //   const { offsetHeight, offsetWidth } = img;
    //   console.log(img.offsetWidth);
    // };
    const _handleImageChange = (e)=>{
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];
        if (!file.name.match(/\.(jpg|jpeg|png|gif)$/)) {
            alert("Choose Correct picture format jpg/jpeg/png/gif");
            setimagedata({
                file: "",
                imageblob: ""
            });
            e.target.value = null;
            return false;
        } else {
            reader.onloadend = ()=>{
                setimagedata({
                    file: file,
                    imagePreviewUrl: reader.result
                });
                setimagecloud(file);
            };
        }
        reader.readAsDataURL(file);
    };
    const setImageSize = (setImageDimensions, imageUrl)=>{
        if (!imageUrl === undefined) {
            const img = new (next_image__WEBPACK_IMPORTED_MODULE_3___default())();
            img.src = imageUrl;
            img.onload = ()=>{
                setImageDimensions({
                    height: img.height,
                    width: img.width
                });
            //console.log(setImageDimensions.height)
            };
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (imagedata) {
            setimagePreview(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: imagedata.imagePreviewUrl,
                onClick: (e)=>{
                    console.log(e.clientX + " - " + e.clientY);
                }
            }));
        } else {
            setimagedata({
                file: "",
                imageblob: ""
            });
            setimagePreview(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-txtborderColor font-poppins text-sm",
                children: "Select Image"
            }));
        }
    }, [
        imagedata
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "py-5",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "max-w-4xl rounded-2xl overflow-hidden mx-auto bg-lightgrey py-5",
            style: {
                boxShadow: "rgba(0, 0, 0, 0.1) 0px 4px 12px"
            },
            children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative w-full h-screen my-28 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "absolute left-1/2 top-1/2 w-28 h-32 m-auto text-center text-txtborderColor text-2xl",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_5__.BallTriangle, {
                            color: "#9bbcd1",
                            height: "100",
                            width: "100",
                            ariaLabel: "loading"
                        }),
                        " Updating..."
                    ]
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "px-10 pt-10 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    onSubmit: handleSubmit(onSubmit),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-24 h-32 object-contain rounded-2xl overflow-hidden shadow-md shadow-txtborderColor mx-auto border-solid border-2 border-txtborderColor bg-lightgrey ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: "text-txtborderColor font-poppins text-sm text-center overflow-hidden",
                                    type: "file",
                                    ref: imgref,
                                    ...register("coinimage", {
                                        required: true
                                    }),
                                    onChange: (e)=>_handleImageChange(e)
                                    ,
                                    onLoad: (e)=>setChandra()
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-24 h-24 border-2 border-solid border-txtborderColor rounded-lg mx-auto",
                                    children: imagePreview
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-red-400 text-center",
                            children: errors.coinimage?.type === "required" && "Coin image is Required"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-row flex-wrap py-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: " basis-full md:basis-1/2 block md:inline-block",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "md:pr-5",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full ",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "text-txtborderColor pb-10 text-left text-md md:text-xl ",
                                                    children: "Coin Name"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-full",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                            type: "text",
                                                            placeholder: "Coin Name",
                                                            ...register("coinname", {
                                                                required: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "text-red-400",
                                                            children: errors.coinname?.type === "required" && "Coin Name is Required"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-1/2 block md:inline-block",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor pb-10 text-left text-md md:text-xl ",
                                            children: "Coin Symbol"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                    type: "text",
                                                    placeholder: "Coin Symbol",
                                                    ...register("coinsymbol", {
                                                        required: true
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-red-400",
                                                    children: errors.coinsymbol?.type === "required" && "Coin symbol is Required"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-row flex-wrap",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: " basis-full md:basis-4/6 text-txtborderColor inline-block",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                className: "text-txtborderColor pb-10 text-left text-md md:text-xl",
                                                children: "Chain/Network"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full md:pr-5",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                className: "bg-bodygray w-full font-poppins border-2 border-txtborderColor py-1",
                                                ...register("networkchain", {
                                                    required: true
                                                }),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "Ethereum",
                                                        children: "Ethereum"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "BNB",
                                                        children: "BNB"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-2/6 inline-block",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor text-left text-md md:text-xl ",
                                            children: "Launch Date"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                    type: "date",
                                                    placeholder: "Launch Date",
                                                    ...register("launchdate", {
                                                        required: true
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-red-400",
                                                    children: errors.launchdate?.type === "required" && "Launch Date is Required"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-row flex-wrap py-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-1/6 text-txtborderColor inline-block",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                className: "text-txtborderColor pb-10 text-left text-md md:text-xl",
                                                children: "Listing Status"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full md:pr-5",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                id: "lstat",
                                                className: "bg-bodygray w-full font-poppins border-2 border-txtborderColor py-1",
                                                ...register("listingstatus", {
                                                    required: true
                                                }),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "presale",
                                                        children: "Pre-Sale"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "listed",
                                                        children: "Listed"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-5/6 inline-block",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor pb-10 text-left text-md md:text-xl ",
                                            children: "Contract Address"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    id: "cont",
                                                    className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                    type: "text",
                                                    placeholder: "Contract Address",
                                                    ...register("contractaddress", {
                                                        required: false
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-red-400",
                                                    children: errors.contractaddress?.type === "pattern" && "Invalid site name"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full inline-block",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                    className: "text-txtborderColor pb-10 text-md md:text-xl ",
                                    children: "Description"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                            className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor",
                                            placeholder: "Description",
                                            rows: "8",
                                            ...register("description", {
                                                required: true,
                                                maxLength: 500
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "text-red-400",
                                            children: [
                                                errors.description?.type === "required" && "Description is Required",
                                                errors.description?.type === "maxLength" && "Maximum 500 characters"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-row flex-wrap py-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-2/6 md:inline-block block",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor pb-10 text-left text-md md:text-xl",
                                            children: "Website Link"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "md:pr-5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: "bg-bodygray text-txtborderColor w-full font-poppins border-2 border-txtborderColor py-1",
                                                    type: "text",
                                                    placeholder: "Website Link",
                                                    ...register("websitelink", {
                                                        required: {
                                                            value: true,
                                                            message: "Url is required"
                                                        },
                                                        pattern: {
                                                            value: /^((ftp|http|https):\/\/)?www\.([A-z]+)\.([A-z]{2,})/,
                                                            message: "Please enter a valid url"
                                                        }
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-red-400",
                                                    children: errors.websitelink?.type === "pattern" && "URL is Required"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-2/6 md:inline-block block ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor pb-10 text-left text-md md:text-xl ",
                                            children: "Twitter Link"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "md:pr-5",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                type: "text",
                                                placeholder: "Twitter Link",
                                                ...register("twitterlink", {
                                                    required: false
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-2/6 md:inline-block block",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor pb-10 text-left text-md md:text-xl ",
                                            children: "Chart Link"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                type: "text",
                                                placeholder: "Chart Link",
                                                ...register("chartlink", {
                                                    required: false
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-row flex-wrap py-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-2/6 md:inline-block block",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor pb-10 text-left text-md md:text-xl",
                                            children: "Reddit Link"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "md:pr-5",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                type: "text",
                                                placeholder: "Reddit Link",
                                                ...register("redditlink", {
                                                    required: false
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-2/6 md:inline-block block ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor pb-10 text-left text-md md:text-xl ",
                                            children: "Discord Link"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "md:pr-5",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                type: "text",
                                                placeholder: "Discord Link",
                                                ...register("discordlink", {
                                                    required: false
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "basis-full md:basis-2/6 md:inline-block block",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor pb-10 text-left text-md md:text-xl",
                                            children: "Telegram Link"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                type: "text",
                                                placeholder: "Telegram Link",
                                                ...register("telegramlink", {
                                                    required: false
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text-center w-3/6 md:w-1/3 pt-4 md:mx-auto",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mx-auto",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_google_recaptcha__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        //sitekey="6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI"
                                        //ref={reRef}
                                        sitekey: skey,
                                        onChange: (e)=>{
                                            setIsCaptcha(true);
                                            setCaptcha(e);
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "py-4",
                                    children: iscaptcha ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        type: "submit",
                                        children: "Submit"
                                    }) : null
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListCoinForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;