exports.id = 554;
exports.ids = [554];
exports.modules = {

/***/ 664:
/***/ ((module) => {

// Exports
module.exports = {
	"wrapper": "searchButton_wrapper__4_CQq",
	"focus": "searchButton_focus__HgV_7",
	"search": "searchButton_search__5AXxM",
	"list": "searchButton_list__a0td7",
	"enlarge": "searchButton_enlarge__7dxv7",
	"result": "searchButton_result__7l_oi"
};


/***/ }),

/***/ 2554:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ui_searchButton_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(664);
/* harmony import */ var _ui_searchButton_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ui_searchButton_module_css__WEBPACK_IMPORTED_MODULE_3__);




// Dummy data
//const REQUEST_URL = 'https://jonasjacek.github.io/colors/data.json';
const REQUEST_URL = (/* unused pure expression or super */ null && ("/api/searchcoin"));
// class Search extends React.Component {
function Search() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const { 0: search , 1: setSearch  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const { 0: data1 , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    // state = {
    //   data: null,
    //   search: "",
    //   color: ""
    // }
    // fetch data
    // componentDidMount() {
    //   fetch('/api/searchcoin')
    //     .then(response => response.json())
    //     .then((data) => {this.setState(data.coinlist);console.log(data.coinlist);})
    // }
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        fetch("/api/searchcoin").then((response)=>response.json()
        ).then((data)=>{
            setData(data.coinlist); //console.log(data.coinlist);
        });
    }, []);
    // Search input   
    //onInput = e => this.setState({ [e.target.id]: e.target.value });
    // onInput = (e) => {setSearch( {e.target.value })};
    // Select the wrapper and toggle class 'focus'
    // onFocus = e => e.target.parentNode.parentNode.classList.add('focus');
    // onBlur = e => e.target.parentNode.parentNode.classList.remove('focus');
    // Select item
    // onClickItem = item => this.setState({
    //   search: "",
    //   color: item
    // });
    const onClickItem = (item)=>{
        router.push(`/${item._id}`);
        setSearch("");
    // setColor(item);
    };
    // this.setState({
    //    search: "",
    //   color: item
    // });
    if (!data1) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "text-white",
            children: "Loading"
        });
    }
    //console.log("lll",data);
    let filtered = data1.filter((item)=>item.coinname.toLowerCase().includes(search.toLowerCase())
    );
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_ui_searchButton_module_css__WEBPACK_IMPORTED_MODULE_3___default().wrapper),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_ui_searchButton_module_css__WEBPACK_IMPORTED_MODULE_3___default().search),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "p-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                fill: "#9bbcd1",
                                xmlns: "http://www.w3.org/2000/svg",
                                viewBox: "0 0 24 24",
                                width: "24px",
                                height: "24px",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "border-none",
                            id: "search",
                            type: "search",
                            value: search,
                            placeholder: " Search Token",
                            onChange: (e)=>{
                                setSearch(e.target.value);
                            },
                            onFocus: (e)=>e.target.parentNode.parentNode.classList.add("focus")
                        })
                    ]
                }),
                search.length > 1 && filtered.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: (_ui_searchButton_module_css__WEBPACK_IMPORTED_MODULE_3___default().list),
                    children: filtered.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            onClick: ()=>onClickItem(item)
                            ,
                            children: item.coinname
                        }, item._id)
                    )
                })
            ]
        })
    });
}
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Search);


/***/ })

};
;