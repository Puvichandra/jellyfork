"use strict";
exports.id = 482;
exports.ids = [482];
exports.modules = {

/***/ 3482:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "kt": () => (/* binding */ insertData),
/* harmony export */   "vk": () => (/* binding */ connectDatabse)
/* harmony export */ });
/* unused harmony exports getAllDocuments, addVoteNow, updateData */
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8013);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);

async function connectDatabse(dbname) {
    const client = await mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient.connect("mongodb+srv://chandra:3GXvlZhcibsu3sKj@cluster0.onchbsj.mongodb.net/" + dbname + "?retryWrites=true&w=majority");
    return client;
}
async function insertData(client, collection, document) {
    const db = client.db();
    const result = await db.collection(collection).insertOne(document);
    return result;
}
async function getAllDocuments(client, collection) {
    const db = client.db();
    const documents = await db.collection(collection).find().toArray();
    return documents;
}
function addVoteNow(id) {
    fetch("api/votenow/" + id).then((res)=>res.json()
    ).then((data)=>{
        console.log(data);
    });
}
async function updateData(client, collection, id) {
    const db = client.db();
    const result = await db.collection(collection).updateOne({
        _id: new ObjectId(id)
    }, {
        $set: {
            description: "Chandra"
        }
    });
    return result;
}


/***/ })

};
;