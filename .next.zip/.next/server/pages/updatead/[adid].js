"use strict";
(() => {
var exports = {};
exports.id = 243;
exports.ids = [243];
exports.modules = {

/***/ 7855:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5641);
/* harmony import */ var _ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5368);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1223);
/* harmony import */ var react_loader_spinner__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_loader_spinner__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5623);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_google_recaptcha__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_1__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




// import { ImageUpload } from '../ui/upload-preview'






function AdUpdateForm(props) {
    const { 0: adid , 1: setAdId  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: adposition , 1: setAdPosition  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: adimage , 1: setAdImage  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: oldadimage , 1: setOldAdImage  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: fromdate , 1: setFromDate  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: todate , 1: setToDate  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: adactive , 1: setAdActive  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: adlink , 1: setAdLink  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const { 0: isLoading , 1: SetIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("false");
    const imgref = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const { 0: imagePreview , 1: setimagePreview  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const { 0: imagedata , 1: setimagedata  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({
        file: "",
        imageblob: ""
    });
    const { 0: imagecloud , 1: setimagecloud  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const options = [
        {
            value: "",
            text: "--Choose an option--"
        },
        {
            value: "top-banner",
            text: "Top Banner"
        },
        {
            value: "mid-left",
            text: "Middle Left"
        },
        {
            value: "mid-right",
            text: "Middle Right"
        },
        {
            value: "bottom-banner",
            text: "Bottom"
        }, 
    ];
    function updateAddData() {
        SetIsLoading(false);
        let item = {
            adid,
            adposition,
            adimage,
            fromdate,
            todate,
            adactive,
            adlink,
            oldadimage
        };
        if (imagecloud) {
            const formData = new FormData();
            // console.log("hhh",imagecloud);
            formData.append("file", imagecloud);
            formData.append("upload_preset", "akcblzz9");
            //Axios.post("http://api.cloudinary.com/v1_1/dp9yoy7js/image/upload", formData)
            axios__WEBPACK_IMPORTED_MODULE_7___default().post("http://api.cloudinary.com/v1_1/dp9yoy7js/image/upload", formData).then((response)=>{
                item.adimage = response.data.secure_url;
                updateAdUpdateData(item);
            }).catch((e)=>{
                SetIsLoading(false);
                alert("error  loading  picture in cloudinary");
            });
        } else {
            item.adimage = props.data[0].adimage;
            updateAdUpdateData(item);
        }
    }
    function updateAdUpdateData(item) {
        SetIsLoading(false);
        //let item={adid,adposition,adimage,fromdate,todate,adactive,adlink}
        //console.warn("item",item)
        //C:\Users\91770\jf-next-app\pages\api\adapidata.js
        fetch("/api/adapidata", {
            method: "PUT",
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            body: JSON.stringify(item)
        }).then((result)=>{
            result.json().then((resp)=>{
                //console.warn(resp);
                SetIsLoading(true);
            });
        });
    }
    const _handleImageChange = (e)=>{
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];
        if (!file.name.match(/\.(jpg|jpeg|png|gif)$/)) {
            alert("Choose Correct picture format jpg/jpeg/png/gif");
            setimagedata({
                file: "",
                imageblob: ""
            });
            e.target.value = null;
            return false;
        } else {
            reader.onloadend = ()=>{
                setimagedata({
                    file: file,
                    imagePreviewUrl: reader.result
                });
                setimagecloud(file);
            };
        }
        reader.readAsDataURL(file);
    };
    function getContactMessage() {
        SetIsLoading(false);
        setAdId(props.data[0]._id);
        setAdPosition(props.data[0].adposition);
        setAdImage(props.data[0].adimage);
        setOldAdImage(props.data[0].adimage);
        setFromDate(props.data[0].fromdate);
        setToDate(props.data[0].todate);
        setAdActive(props.data[0].adactive);
        setAdLink(props.data[0].adlink);
        SetIsLoading(true);
    }
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (imagedata.file) {
            setimagePreview(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: "mx-auto px-5 py-5",
                src: imagedata.imagePreviewUrl,
                alt: "No Image",
                onClick: (e)=>{
                    console.log(e.clientX + " - " + e.clientY);
                }
            }));
        } else {
            //setimagedata({file:{adimage}, imageblob:''})
            //setimagePreview (<div className="text-txtborderColor font-poppins text-sm">Select Image</div>);
            setimagePreview(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: "mx-auto px-5 py-2",
                src: adimage,
                alt: "No Image"
            }));
        }
        getContactMessage();
    //setimagePreview (<img className="mx-auto px-5 py-2" src={adimage}/>)
    }, [
        props.data._id,
        imagedata,
        adimage
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            !isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-screen h-screen",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "absolute left-1/2 top-1/2 text-center w-14 h-14 mx-auto ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loader_spinner__WEBPACK_IMPORTED_MODULE_5__.Watch, {
                        height: "100",
                        width: "100",
                        color: "white",
                        ariaLabel: "loading"
                    })
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "py-5 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "max-w-4xl mx-auto overflow-hidden shadow-md border-2 border-txtborderColor rounded-xl p-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "inline pr-2 text-txtborderColor text-2xl text-center font-bold font-poppins pl-10",
                            children: "Admin Control Panel Adverisement"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "px-10 pt-10 ",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                className: "text-txtborderColor pb-10 text-left text-md md:text-xl",
                                                children: "Select Ad Banner"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                            className: "bg-bodygray w-1/2 font-poppins border-2 text-txtborderColor border-txtborderColor py-1 ",
                                            value: adposition,
                                            onChange: (e)=>{
                                                setAdPosition(e.target.value);
                                            },
                                            children: options.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                    value: option.value,
                                                    children: option.text
                                                }, option.value)
                                            )
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "pt-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: "text-txtborderColor font-poppins text-sm text-center overflow-hidden",
                                            type: "file",
                                            ref: imgref,
                                            onChange: (e)=>_handleImageChange(e)
                                            ,
                                            onLoad: (e)=>setChandra()
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full h-32 border-2 border-solid border-txtborderColor rounded-lg mx-auto",
                                            children: imagePreview
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-1/2 ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor text-left text-md md:text-xl ",
                                            children: "From Date"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                value: fromdate,
                                                type: "date",
                                                placeholder: "From Date",
                                                onChange: (e)=>{
                                                    setFromDate(e.target.value);
                                                }
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-1/2 ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor text-left text-md md:text-xl ",
                                            children: "To Date"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: "bg-bodygray w-full text-txtborderColor font-poppins border-2 border-txtborderColor py-1",
                                                value: todate,
                                                type: "date",
                                                placeholder: "To Date",
                                                onChange: (e)=>{
                                                    setToDate(e.target.value);
                                                }
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-1/2 text-txtborderColor ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                className: "text-txtborderColor pb-10 text-left text-md md:text-xl",
                                                children: "Activate "
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full md:pr-5",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                className: "bg-bodygray w-full font-poppins border-2 border-txtborderColor py-1",
                                                value: adactive,
                                                onChange: (e)=>{
                                                    setToDate(e.target.value);
                                                },
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "activate",
                                                        children: "Activate"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        value: "deactivate",
                                                        children: "Deactivate"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-1/2 md:basis-2/6 md:inline-block block ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-txtborderColor pb-10 text-left text-md md:text-xl",
                                            children: "Ad Link"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "md:pr-5",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                className: "bg-bodygray text-txtborderColor w-full font-poppins border-2 border-txtborderColor py-1",
                                                value: adlink,
                                                type: "text",
                                                placeholder: "Ad Web Link",
                                                onChange: (e)=>{
                                                    setAdLink(e.target.value);
                                                }
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-center pt-10",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        onClick: updateAddData,
                                        children: "Update"
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            " "
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AdUpdateForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1790:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8013);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_coinlist_update_ad_data__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7855);
/* harmony import */ var _helpers_db_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4325);
/* harmony import */ var _components_layout_admin_header__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9873);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_coinlist_update_ad_data__WEBPACK_IMPORTED_MODULE_4__]);
_components_coinlist_update_ad_data__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function AdDetailsPage(props) {
    const data = props.AdData;
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const refreshData = ()=>{
        router.replace(router.asPath);
    };
    //  useEffect(()=>{
    //   refreshData()
    //  },[isLoading])
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_admin_header__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_coinlist_update_ad_data__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                data: data,
                loadingstate: isLoading
            })
        ]
    });
}
async function getServerSideProps(context) {
    const { params  } = context;
    const AdId = params.adid;
    let document;
    let client;
    try {
        client = await (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_5__/* .connectDatabse */ .vk)("coindata");
    } catch  {
        console.log("database connection failed");
        return;
    }
    try {
        const db = client.db();
        //document = await db.collection('coinlist').find({_id:ObjectId("62b5cebc09291b1531ebcbd3")}).toArray();
        document = await db.collection("adlist").find({
            _id: new mongodb__WEBPACK_IMPORTED_MODULE_1__.ObjectId(AdId)
        }).toArray();
    } catch  {
        console.log("Unable to get documents");
    }
    client.close();
    return {
        props: {
            AdData: JSON.parse(JSON.stringify(document)),
            id: AdId
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AdDetailsPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5623:
/***/ ((module) => {

module.exports = require("react-google-recaptcha");

/***/ }),

/***/ 1223:
/***/ ((module) => {

module.exports = require("react-loader-spinner");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,675,368,554,873,325], () => (__webpack_exec__(1790)));
module.exports = __webpack_exports__;

})();