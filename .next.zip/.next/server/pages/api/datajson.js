"use strict";
(() => {
var exports = {};
exports.id = 710;
exports.ids = [710];
exports.modules = {

/***/ 789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "buildpath": () => (/* binding */ buildpath),
  "default": () => (/* binding */ datajson),
  "extractdata": () => (/* binding */ extractdata)
});

;// CONCATENATED MODULE: external "fs"
const external_fs_namespaceObject = require("fs");
var external_fs_default = /*#__PURE__*/__webpack_require__.n(external_fs_namespaceObject);
;// CONCATENATED MODULE: external "path"
const external_path_namespaceObject = require("path");
var external_path_default = /*#__PURE__*/__webpack_require__.n(external_path_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/datajson.js


function buildpath() {
    return external_path_default().join(process.cwd(), "data", "datafile.json");
}
function extractdata(filepath) {
    const exdata = external_fs_default().readFileSync(filepath);
    const edata = JSON.parse(exdata);
    return edata;
}
function handler(req, res) {
    if (req.method === "POST") {
        const coinname = req.body.coinname;
        const coinimage = req.body.coinimage;
        const coinsymbol = req.body.coinsymbol;
        const contractaddress = req.body.contractaddress;
        const description = req.body.description;
        const discordlink = req.body.discordlink;
        const launchdate = req.body.launchdate;
        const listingstatus = req.body.listingstatus;
        const networkchain = req.body.networkchain;
        const reditlink = req.body.redditlink;
        const telegramlink = req.body.telegramlink;
        const twitterlink = req.body.twitterlink;
        const websitelink = req.body.websitelink;
        const newcoin = {
            id: new Date().toISOString(),
            coinimage: coinimage,
            coinname: coinname,
            coinsymbol: coinsymbol,
            contractaddress: contractaddress,
            description: description,
            discordlink: discordlink,
            launchdate: launchdate,
            listingstatus: listingstatus,
            networkchain: networkchain,
            reditlink: reditlink,
            telegramlink: telegramlink,
            twitterlink: twitterlink,
            websitelink: websitelink,
            promotedcoin: "false"
        };
        const filepath = buildpath();
        const edata = extractdata(filepath);
        edata.push(newcoin);
        external_fs_default().writeFileSync(filepath, JSON.stringify(edata));
        res.status(201).json({
            message: "success",
            datafile: edata
        });
    } else {
        const filepath = buildpath();
        const edata = extractdata(filepath);
        res.status(200).json({
            datafile: edata
        });
    //    res.status(200).json({message:"Success"});
    }
}
/* harmony default export */ const datajson = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(789));
module.exports = __webpack_exports__;

})();