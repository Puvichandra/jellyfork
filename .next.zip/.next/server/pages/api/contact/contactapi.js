"use strict";
(() => {
var exports = {};
exports.id = 877;
exports.ids = [877];
exports.modules = {

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 43:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8013);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _helpers_db_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3482);


async function handler(req, res1) {
    let client;
    if (req.method === "POST") {
        const { username , teleusername , useremail , userpurpose , usermessage , captcha  } = req.body;
        if (!captcha || captcha === undefined || captcha === null) {
            return res1.json({
                message: "Captcha Failed"
            });
        }
        //Secret Key
        const secKey = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe";
        const verifyURL = `https://www.google.com/recaptcha/api/siteverify?secret=${secKey}&response=${captcha}$remoteip=${req.connection.remoteAddress}`;
        //make request
        const body = await fetch(verifyURL).then((res)=>res.json()
        );
        // If not successful
        if (body.success !== undefined && !body.success) {
            return res1.json({
                success: false,
                msg: "Failed captcha verification"
            });
        }
        if (!username || !username.trim() === "" || !useremail || !useremail.trim() === "" || !userpurpose || !userpurpose.trim() === "" || !usermessage || usermessage.trim() === "") {
            res1.status(422).json({
                message: "Input Invalid"
            });
            client.close();
            return;
        } else {
            const newMessage = {
                username,
                teleusername,
                useremail,
                userpurpose,
                usermessage,
                datereceived: new Date().toLocaleString(),
                checked: "Awaiting",
                action: "Not Started",
                remarks: ""
            };
            //console.log(newMessage)                  
            try {
                // client = await MongoClient.connect('mongodb+srv://chandra:3GXvlZhcibsu3sKj@cluster0.onchbsj.mongodb.net/coindata?retryWrites=true&w=majority');
                client = await (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_1__/* .connectDatabse */ .vk)("coindata");
            } catch  {
                res1.status(201).json({
                    message: "denied"
                });
                return;
            }
            try {
                const db = client.db();
                const result = await db.collection("contactmessage").insertOne(newMessage);
                //const result = insertData(client,'contactmessage', newMessage)
                res1.status(201).json({
                    message: "Message added"
                });
            } catch  {
                res1.status(500).json({
                    message: "Message not inserted"
                });
            }
        }
        client.close();
    }
    if (req.method === "GET") {
        try {
            // client = await MongoClient.connect('mongodb+srv://chandra:3GXvlZhcibsu3sKj@cluster0.onchbsj.mongodb.net/coindata?retryWrites=true&w=majority');
            client = await (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_1__/* .connectDatabse */ .vk)("coindata");
        } catch  {
            res1.status(201).json({
                message: "denied"
            });
            return;
        }
        try {
            const db = client.db();
            const documents = await db.collection("contactmessage").find({}, {
                projection: {
                    "username": 1,
                    "useremail": 1,
                    "datereceived": 1,
                    "userpurpose": 1,
                    "checked": 1,
                    "action": 1
                }
            }).sort({
                "username": -1,
                "datereceived": -1
            }).toArray();
            //const result = insertData(client,'contactmessage', newMessage)
            res1.status(200).json({
                contactmsg: documents
            });
        } catch  {
            res1.status(500).json({
                message: "Fetching Data Error"
            });
        }
        client.close();
    }
    if (req.method === "PUT") {
        //contactid,telegramlink,contactaction,contactchecked,contactremarks
        const { contactid , contactremarks , contactaction , contactchecked , telegramlink  } = req.body;
        //console.log("nnn", contactremarks);
        try {
            client = await (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_1__/* .connectDatabse */ .vk)("coindata");
        } catch  {
            res1.status(500).json({
                message: "Database connection failed"
            });
            return;
        }
        try {
            const db = client.db();
            const result = await db.collection("contactmessage").updateOne({
                _id: new mongodb__WEBPACK_IMPORTED_MODULE_0__.ObjectId(contactid)
            }, {
                $set: {
                    remarks: contactremarks,
                    action: contactaction,
                    checked: contactchecked,
                    teleusername: telegramlink
                }
            }, {
                upsert: false
            });
            //console.log(result);
            res1.status(200).json({
                message: "Record updated"
            });
        } catch  {
            res1.status(500).json({
                message: "Error in updating"
            });
        }
        client.close();
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [482], () => (__webpack_exec__(43)));
module.exports = __webpack_exports__;

})();