"use strict";
(() => {
var exports = {};
exports.id = 370;
exports.ids = [370];
exports.modules = {

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 2820:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8013);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _helpers_db_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3482);

//import sha1 from sha1;

// MongoClient
async function handler(req, res1) {
    let client;
    if (req.method === "POST") {
        const { adposition , adimage , fromdate , todate , adactive , adlink , captcha  } = req.body;
        if (!captcha || captcha === undefined || captcha === null) {
            return res1.json({
                message: "Captcha Failed"
            });
        }
        //Secret Key
        const secKey = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe";
        const verifyURL = `https://www.google.com/recaptcha/api/siteverify?secret=${secKey}&response=${captcha}$remoteip=${req.connection.remoteAddress}`;
        //make request
        const body = await fetch(verifyURL).then((res)=>res.json()
        );
        // If not successful
        if (body.success !== undefined && !body.success) {
            return res1.json({
                success: false,
                msg: "Failed captcha verification"
            });
        }
        //console.log("body",req.body)
        if (!adposition || !adposition.trim() === "" || !adimage || !adimage.trim() === "" || !fromdate || !fromdate.trim() === "" || !todate || !todate.trim() === "" || !adactive || !adactive.trim() === "" || !adlink || !adlink.trim() === "") {
            res1.status(422).json({
                message: "Input Invalid"
            });
            client.close();
            return;
        } else {
            const newad = {
                adposition,
                adimage,
                fromdate,
                todate,
                adactive,
                adlink
            };
            try {
                // client = await MongoClient.connect('mongodb+srv://chandra:3GXvlZhcibsu3sKj@cluster0.onchbsj.mongodb.net/coindata?retryWrites=true&w=majority');
                client = await (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_1__/* .connectDatabse */ .vk)("coindata");
                res1.status(201).json({
                    message: "ok"
                });
            } catch  {
                res1.status(201).json({
                    message: "denied"
                });
                return;
            }
            try {
                // const db=client.db();
                // const result = await db.collection('coinlist').insertOne(newCoin);
                const result = (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_1__/* .insertData */ .kt)(client, "adlist", newad);
                res1.status(201).json({
                    message: "added"
                });
            } catch  {
                res1.status(500).json({
                    message: "data not inserted"
                });
            }
        }
        client.close();
    }
    if (req.method === "GET") {
        try {
            client = await (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_1__/* .connectDatabse */ .vk)("coindata");
        } catch  {
            res1.status(500).json({
                message: "Database connection failed"
            });
            return;
        }
        try {
            const db = client.db();
            const documents = await db.collection("adlist").find({}, {
                projection: {
                    "adimage": 1,
                    "adactive": 1,
                    "adposition": 1,
                    "fromdate": 1,
                    "todate": 1,
                    "adlink": 1
                }
            }).sort({
                "adposition": -1
            }).toArray();
            //const promoteddocument = await db.collection('nftlist').find({ispromoted:true , ispromoted:"true"}, {projection:{"coinname":1, "marketcap":1, "price":1, "votes":1, "daysago":1, "ispromoted":1}} ).sort({"votes":-1}).toArray();
            res1.status(201).json({
                adlist: documents
            });
        //console.log("Chandra",promoteddocument)
        } catch  {
            res1.status(500).json({
                message: "Unable to get documents"
            });
        }
        client.close();
    }
    if (req.method === "PUT") {
        const { adid , adposition , adimage , fromdate , todate , adactive , adlink , oldadimage  } = req.body;
        //console.log(req.body);
        if (!adposition || !adposition.trim() === "" || !adimage || !adimage.trim() === "" || !fromdate || !fromdate.trim() === "" || !todate || !todate.trim() === "" || !adactive || !adactive.trim() === "" || !adlink || !adlink.trim() === "") {
            res1.status(422).json({
                message: "Input Invalid"
            });
            return;
        }
        // deleteOldImage (oldadimage);       
        try {
            client = await (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_1__/* .connectDatabse */ .vk)("coindata");
        } catch  {
            res1.status(500).json({
                message: "Database connection failed"
            });
            return;
        }
        try {
            const db = client.db();
            const result = await db.collection("adlist").updateOne({
                _id: new mongodb__WEBPACK_IMPORTED_MODULE_0__.ObjectId(adid)
            }, {
                $set: {
                    adposition: adposition,
                    adimage: adimage,
                    fromdate: fromdate,
                    todate: todate,
                    adactive: adactive,
                    adlink: adlink
                }
            }, {
                upsert: false
            });
            // deleteOldImage (oldadimage);
            res1.status(200).json({
                message: "Record updated"
            });
        } catch  {
            res1.status(500).json({
                message: "Error in updating"
            });
        }
        client.close();
    // }
    }
}
async function deleteOldImage(oldadimage) {
    const filename = oldadimage.split("/");
    var lastSegment = filename.pop() || parts.pop(); // handle potential trailing slash
    //console.log(lastSegment);
    const timestamp = new Date().getTime();
    const string = `public_id=ofsgnoxe0apifeajp4lu&timestamp=${timestamp}Hi_zdlfAnGTB4hOOxRrKjgi2r0o`;
    const signature = await sha1(string);
    const formData = new FormData();
    formData.append("public_id", "ofsgnoxe0apifeajp4lu");
    formData.append("signature", signature);
    formData.append("api_key", "462743359482371");
    formData.append("timestamp", timestamp);
    const res = await ax.post("https://api.cloudinary.com/v1_1/ofsgnoxe0apifeajp4lu/image/destroy", formData);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [482], () => (__webpack_exec__(2820)));
module.exports = __webpack_exports__;

})();