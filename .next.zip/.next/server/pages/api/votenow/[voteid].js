"use strict";
(() => {
var exports = {};
exports.id = 202;
exports.ids = [202];
exports.modules = {

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 1575:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _helpers_db_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3482);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8013);
/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_1__);


async function handler(req, res1) {
    let client;
    // if (req.method==='GET'){
    //     const id = req.query.voteid;
    //     // console.log("Chandra",id);
    //     try {
    //         client=await connectDatabse('coindata');
    //     } catch {
    //         res.status(500).json({message:"Database connection failed"});
    //     }
    //     try {
    //         const db=client.db();
    //         //const document = db.collection('coinlist').findOne({_id:new ObjectId(id)},{projection:{"votes":1, "_id":1}})
    //         await db.collection('coinlist').updateOne({_id:new ObjectId(id)},{ $inc: { "votes": 1 } });
    //         res.status(200).json({message:"added"});
    //     } catch {
    //         res.status(500).json({message:"Not able to fetch documents"})
    //         }
    //     client.close();
    // }
    if (req.method === "POST") {
        const id = req.query.voteid;
        //console.log("jjj",id);
        if (!req.body.captcha || req.body.captcha === undefined || req.body.captcha === null) {
            return res1.json({
                message: "Captcha Failed"
            });
        }
        //Secret Key
        const secKey = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe";
        const verifyURL = `https://www.google.com/recaptcha/api/siteverify?secret=${secKey}&response=${req.body.captcha}$remoteip=${req.connection.remoteAddress}`;
        //make request
        const body = await fetch(verifyURL).then((res)=>res.json()
        );
        // If not successful
        if (body.success !== undefined && !body.success) {
            return res1.json({
                success: false,
                msg: "Failed captcha verification"
            });
        }
        const newIndCoin = {
            coinid: new mongodb__WEBPACK_IMPORTED_MODULE_1__.ObjectId(id),
            datt: Date.now(),
            vote: 1
        };
        try {
            client = await (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_0__/* .connectDatabse */ .vk)("coindata");
        } catch  {
            res1.status(500).json({
                message: "Database connection failed"
            });
        }
        try {
            const db = client.db();
            //const document = db.collection('coinlist').findOne({_id:new ObjectId(id)},{projection:{"votes":1, "_id":1}})
            await db.collection("coinlist").updateOne({
                _id: new mongodb__WEBPACK_IMPORTED_MODULE_1__.ObjectId(id)
            }, {
                $inc: {
                    "votes": 1
                }
            });
            await db.collection("indvidualvote").insertOne(newIndCoin);
            res1.status(200).json({
                message: "added"
            });
        } catch  {
            res1.status(500).json({
                message: "Not able to fetch documents"
            });
        }
        client.close();
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [482], () => (__webpack_exec__(1575)));
module.exports = __webpack_exports__;

})();