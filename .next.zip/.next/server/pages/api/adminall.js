"use strict";
(() => {
var exports = {};
exports.id = 534;
exports.ids = [534];
exports.modules = {

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 8179:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _helpers_db_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3482);

// MongoClient
async function handler(req, res) {
    let client;
    if (req.method === "GET") {
        try {
            client = await (0,_helpers_db_utils__WEBPACK_IMPORTED_MODULE_0__/* .connectDatabse */ .vk)("coindata");
        } catch  {
            res.status(500).json({
                message: "Database connection failed"
            });
            return;
        }
        try {
            const db = client.db();
            const documents = await db.collection("coinlist").find({}, {
                projection: {
                    "coinname": 1,
                    "marketcap": 1,
                    "price": 1,
                    "votes": 1,
                    "daysago": 1,
                    "ispromoted": 1
                }
            }).sort({
                "votes": -1
            }).toArray();
            const promoteddocument = await db.collection("coinlist").find({
                ispromoted: true,
                ispromoted: "true"
            }, {
                projection: {
                    "coinname": 1,
                    "marketcap": 1,
                    "price": 1,
                    "votes": 1,
                    "daysago": 1,
                    "ispromoted": 1
                }
            }).sort({
                "votes": -1
            }).toArray();
            res.status(201).json({
                coinlist: documents,
                promoted: promoteddocument
            });
        //console.log("Chandra",promoteddocument)
        } catch  {
            res.status(500).json({
                message: "Unable to get documents"
            });
        }
        client.close();
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [482], () => (__webpack_exec__(8179)));
module.exports = __webpack_exports__;

})();