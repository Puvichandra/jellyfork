"use strict";
(() => {
var exports = {};
exports.id = 217;
exports.ids = [217];
exports.modules = {

/***/ 5083:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _coinid_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./helpers/db-utils.js
var db_utils = __webpack_require__(4325);
// EXTERNAL MODULE: external "mongodb"
var external_mongodb_ = __webpack_require__(8013);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/ui/button.js
var ui_button = __webpack_require__(5368);
// EXTERNAL MODULE: external "react-loader-spinner"
var external_react_loader_spinner_ = __webpack_require__(1223);
// EXTERNAL MODULE: external "react-modal"
var external_react_modal_ = __webpack_require__(9931);
var external_react_modal_default = /*#__PURE__*/__webpack_require__.n(external_react_modal_);
// EXTERNAL MODULE: external "react-google-recaptcha"
var external_react_google_recaptcha_ = __webpack_require__(5623);
var external_react_google_recaptcha_default = /*#__PURE__*/__webpack_require__.n(external_react_google_recaptcha_);
;// CONCATENATED MODULE: ./components/coinlist/detail-page.js








function DetailPageCoin(props) {
    //console.log(props.data[0])
    const skey = "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI";
    const customStyles = {
        content: {
            top: "50%",
            left: "50%",
            right: "auto",
            bottom: "auto",
            marginRight: "-50%",
            transform: "translate(-50%, -50%)"
        }
    };
    //console.log('ddd',props);
    const { 0: ismodalopen , 1: setismodalopen  } = (0,external_react_.useState)(false);
    const [captcha, setCaptcha] = "";
    function handleClick() {
        setismodalopen(true);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((external_react_modal_default()), {
                isOpen: ismodalopen,
                style: customStyles,
                ariaHideApp: false,
                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_google_recaptcha_default()), {
                    sitekey: skey,
                    onChange: (e)=>{
                        setismodalopen(false);
                        props.evote(props.data[0]._id, e);
                    }
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full md:w-11/12 2xl:w-8/12 mx-auto py-20 flex flex-row flex-wrap gap-1",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full md:w-3/6 2xl:px-5 rounded-2xl overflow-hidden mx-auto bg-lightgrey inline-block mr-2 ",
                        style: {
                            boxShadow: "rgba(0, 0, 0, 0.1) 0px 4px 12px"
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "p-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "inline-block px-3",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            className: " rounded-full object-center",
                                            src: props.data[0].coinimage,
                                            alt: "nftone",
                                            width: 100,
                                            height: 100
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "inline-block",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "text-2xl lg:text-4xl text-txtborderColor font-poppins font-bold pl-10 pb-2",
                                                children: props.data[0].coinname
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "pl-2",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    className: "border-2 border-txtborderColor text-white bg-txtborderColor rounded-2xl px-5 font-poppins text-lg mx-8",
                                                    children: [
                                                        "  ",
                                                        props.data[0].coinsymbol
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-txtborderColor py-5 px-2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: props.data[0].description
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row flex-wrap py-5 justify-evenly",
                                children: [
                                    props.data[0].twitterlink ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "basis-1 py-2 ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            type: "button",
                                            className: "border-2 border-txtborderColor text-txtborderColor rounded-2xl px-5 font-poppins text-lg inline mx-2 ",
                                            children: " Twitter"
                                        })
                                    }) : null,
                                    props.data[0].websitelink ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "basis-1 py-2 pl-5 2xl:pl-0",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: props.data[0].websitelink,
                                            type: "button",
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "border-2 border-txtborderColor text-txtborderColor rounded-2xl px-5 font-poppins text-lg inline mx-2",
                                            children: " Website"
                                        })
                                    }) : null,
                                    props.data[0].telegramlink ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "basis-1 py-2 ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            type: "button",
                                            href: props.data[0].telegram,
                                            className: "border-2 border-txtborderColor text-txtborderColor rounded-2xl px-5 font-poppins text-lg inline mx-2 ",
                                            children: " Telegram"
                                        })
                                    }) : null,
                                    props.data[0].facebooklink ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "basis-1 py-2 pl-0 lg:pl-8",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            type: "button",
                                            href: props.data[0].facebook,
                                            className: "border-2 border-txtborderColor text-txtborderColor rounded-2xl px-5 font-poppins text-lg inline mx-2",
                                            children: " Facebook"
                                        })
                                    }) : null
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-2/6 rounded-2xl overflow-hidden mx-auto bg-lightgrey px-2 inline-block ",
                        style: {
                            boxShadow: "rgba(0, 0, 0, 0.1) 0px 4px 12px",
                            marginLeft: "2px"
                        },
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "py-5 pl-5 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-2xl lg:text-4xl text-txtborderColor font-poppins font-bold pl-10 pb-2",
                                    children: "Stats"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "py-2 text-txtborderColor text-xl font-poppins",
                                    children: [
                                        "Price: $",
                                        props.data[0].price
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "py-2 text-txtborderColor text-xl font-poppins",
                                    children: [
                                        "Market Cap: ",
                                        props.data[0].marketcap
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "py-2 text-txtborderColor text-xl font-poppins",
                                    children: [
                                        "Launch Date: ",
                                        props.data[0].launchdate
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "py-2 text-txtborderColor text-xl font-poppins",
                                    children: [
                                        "Total Votes: ",
                                        props.data[0].votes
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "py-5 text-txtborderColor font-poppin",
                                    children: "Have you voted?"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(ui_button/* default */.Z, {
                                    onClick: handleClick,
                                    children: props.loadingstate ? /*#__PURE__*/ jsx_runtime_.jsx(external_react_loader_spinner_.Bars, {
                                        height: "30",
                                        width: "30",
                                        color: "white",
                                        ariaLabel: "loading"
                                    }) : "Vote"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const detail_page = (DetailPageCoin);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./pages/[coinid].js






function CoinDetailPage(props) {
    const id1 = props.id;
    const { 0: isLoading , 1: setIsLoading  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    //   async function updatevote(){
    //     setIsLoading(true);
    //     fetch('api/votenow/'+id)
    //    .then(res=>res.json())
    //    .then((data)=>{
    //     refreshData();
    //     setIsLoading(false);
    //    })
    //  }
    async function updatevote(id, captcha_response) {
        setIsLoading(true);
        const dd = {
            id: "none",
            captcha: captcha_response
        };
        //console.log('kkk',captcha_response);
        fetch("api/votenow/" + id, {
            method: "POST",
            body: JSON.stringify(dd),
            headers: {
                "Content-Type": "application/json"
            }
        }).then((response)=>response.json()
        ).then((data)=>{
            data.message === "added" ? console.log("Data Added") : console.log("Data not Added");
            refreshData();
        });
    }
    const refreshData = ()=>{
        router.replace(router.asPath);
        setIsLoading(false);
    };
    (0,external_react_.useEffect)(()=>{}, [
        props.coinId
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(detail_page, {
            data: props.coinid,
            evote: updatevote,
            loadingstate: isLoading
        })
    });
}
async function getServerSideProps(context) {
    const { params  } = context;
    const coinId = params.coinid;
    let document;
    let client;
    try {
        client = await (0,db_utils/* connectDatabse */.vk)("coindata");
    } catch  {
        console.log("database connection failed");
        return;
    }
    try {
        const db = client.db();
        //document = await db.collection('coinlist').find({_id:ObjectId("62b5cebc09291b1531ebcbd3")}).toArray();
        document = await db.collection("coinlist").find({
            _id: new external_mongodb_.ObjectId(coinId)
        }).toArray();
    } catch  {
        console.log("Unable to get documents");
    }
    client.close();
    return {
        props: {
            coinid: JSON.parse(JSON.stringify(document)),
            id: coinId
        }
    };
}
/* harmony default export */ const _coinid_ = (CoinDetailPage);


/***/ }),

/***/ 8013:
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5623:
/***/ ((module) => {

module.exports = require("react-google-recaptcha");

/***/ }),

/***/ 1223:
/***/ ((module) => {

module.exports = require("react-loader-spinner");

/***/ }),

/***/ 9931:
/***/ ((module) => {

module.exports = require("react-modal");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [505,664,675,368,325], () => (__webpack_exec__(5083)));
module.exports = __webpack_exports__;

})();